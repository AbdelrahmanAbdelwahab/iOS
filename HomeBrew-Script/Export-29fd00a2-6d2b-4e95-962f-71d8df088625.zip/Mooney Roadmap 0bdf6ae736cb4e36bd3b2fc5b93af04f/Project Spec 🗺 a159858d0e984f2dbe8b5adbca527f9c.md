# Project Spec 🗺

Created: February 15, 2022 12:14 PM

# Overview

## Problem statement

Describe the problem we're trying to solve by doing this work.

## Proposed work

High-level overview of what we're building and why we think it'll solve the problem.

# Dependencies & risks

## Stakeholders

Who are the critical stakeholders? Regarding what topics?

- 

## Risks

What are the risks?

- 

## Dependencies

What are the dependencies? Include both internal (other teams) and external (partners).

- 

# Success criteria

The criteria that must be met to consider this project a success. 

-